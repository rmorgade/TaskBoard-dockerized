<?php

$MAIL_HOST = 'smtp.somehost.com';                         // Specify main and backup SMTP servers
$MAIL_USERNAME = 'user@somehost.com';                 // SMTP username
$MAIL_PASSWORD = 'secretpassword';                           // SMTP password
$MAIL_SMTPSECURE = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
$MAIL_PORT = 465;                                    // TCP port to connect to
$MAIL_FROM = 'user@somehost.com';
$MAIL_FROMNAME = 'TaskBoard';
